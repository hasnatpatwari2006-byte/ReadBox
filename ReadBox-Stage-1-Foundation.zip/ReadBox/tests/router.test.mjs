import test from 'node:test';import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
test('router implements root replacement, nested pushes and overlay history',async()=>{
 const s=await readFile(new URL('../src/core/router.js',import.meta.url),'utf8');
 for(const token of ['history.replaceState','history.pushState','state.stack.push(route)','state.overlay=id',"window.addEventListener('popstate'"])assert.ok(s.includes(token),`missing ${token}`);
});
test('router avoids duplicate same-destination entries',async()=>{
 const s=await readFile(new URL('../src/core/router.js',import.meta.url),'utf8');
 assert.ok(s.includes('route===current()'));
});
