import test from 'node:test';import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
test('manifest declares standalone PWA and required theme colours',async()=>{
 const m=JSON.parse(await readFile(new URL('../public/manifest.webmanifest',import.meta.url),'utf8'));
 assert.equal(m.name,'ReadBox');assert.equal(m.display,'standalone');assert.equal(m.theme_color,'#031F51');assert.equal(m.background_color,'#031F51');
});
test('database creates required local stores',async()=>{
 const s=await readFile(new URL('../src/core/db.js',import.meta.url),'utf8');
 for(const name of ['books','settings','collections','annotations','positions','indexes','trash'])assert.ok(s.includes(`'${name}'`));
});
test('exact footer text is present',async()=>{const s=await readFile(new URL('../src/core/app.js',import.meta.url),'utf8');assert.ok(s.includes('ReadBox 2026 All Rights Reserved.'))});
