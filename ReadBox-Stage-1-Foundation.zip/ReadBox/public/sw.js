const BASE='__BASE_PATH__';
const CACHE='readbox-shell-v1';
const CORE=[BASE,BASE+'index.html',BASE+'src/ui/styles.css',BASE+'src/core/app.js',
 BASE+'src/core/router.js',BASE+'src/core/db.js',BASE+'public/manifest.webmanifest',
 BASE+'public/favicon.png',BASE+'public/icons/icon-192.png'];
self.addEventListener('install',event=>event.waitUntil((async()=>{
 const cache=await caches.open(CACHE);
 for(const url of CORE){try{await cache.add(url)}catch(e){console.warn('Precache skipped:',url,e)}}
 await self.skipWaiting();
})()));
self.addEventListener('activate',event=>event.waitUntil((async()=>{
 const keys=await caches.keys();await Promise.all(keys.filter(k=>k.startsWith('readbox-')&&k!==CACHE).map(k=>caches.delete(k)));
 await self.clients.claim();
})()));
self.addEventListener('fetch',event=>{
 const req=event.request;if(req.method!=='GET')return;
 const url=new URL(req.url);if(url.origin!==location.origin)return;
 event.respondWith((async()=>{
  const cached=await caches.match(req);if(cached)return cached;
  try{const response=await fetch(req);if(response.ok&&url.pathname.startsWith(new URL(BASE,location.origin).pathname)){
    const cache=await caches.open(CACHE);cache.put(req,response.clone());
  }return response;}catch{return caches.match(BASE+'index.html')}
 })());
});
