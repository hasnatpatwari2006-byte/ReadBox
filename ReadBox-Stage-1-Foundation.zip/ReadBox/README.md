# ReadBox

Offline-first ebook-reader Progressive Web App for Android phones and tablets.

## Current development status

This delivery contains **Stage 1 — Foundation only**. Later stages are intentionally not represented as completed features. The import button and some Menu destinations are visible as non-functional placeholders until their scheduled stages.

## Stage 1 foundation

- Responsive PWA shell and four root navigation destinations.
- System / Dark / Light theme preference, persisted in IndexedDB.
- IndexedDB schema foundation and persistent-storage request.
- History API navigation stack foundation, nested route and overlay primitives.
- Official owner-supplied logo retained unchanged as `public/logo-original.png`; generated icon sizes are resized from it.
- Web manifest, service worker shell caching and GitHub Pages base-path build script.
- GitHub Actions deployment workflow.

## Honest format status

No ebook format reader is implemented in Stage 1. PDF, EPUB, TXT and additional formats are not yet supported by this build.

## Requirements

Node.js 22 or newer. No third-party runtime dependencies are used in Stage 1.

## Local development

```sh
npm ci
npm run dev
```

Open `http://localhost:4173`.

## Build and tests

```sh
npm test
npm run build
```

For a GitHub Pages project site:

```sh
BASE_PATH=/YOUR_REPOSITORY_NAME/ npm run build
```

In GitHub: Settings → Pages → Build and deployment → Source: GitHub Actions. Push to `main` and wait for the workflow.

## Known limitations / not yet verified

- Stage 1 gate has automated source-level tests, but no real Android Chrome installability, mobile browser, offline browser, or device Back-button test was run in this environment.
- This delivery does not yet include Playwright/browser e2e tests.
- Stage 2–6 features are not implemented.
- Service-worker runtime behavior must be verified on a deployed HTTPS origin.
- The local development server is a minimal static server, not a production server.

## Contact

- Facebook: https://facebook.com/ur.hasnat
- WhatsApp: https://wa.me/8801917115316
