const DB_NAME='readbox-local', DB_VERSION=1;
export function openDB(){
 return new Promise((resolve,reject)=>{
  const req=indexedDB.open(DB_NAME,DB_VERSION);
  req.onupgradeneeded=()=>{const db=req.result;
   for(const name of ['books','settings','collections','annotations','positions','indexes','trash'])
    if(!db.objectStoreNames.contains(name))db.createObjectStore(name,{keyPath:name==='settings'?'key':'id'});
  };
  req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);
 });
}
export async function requestPersistentStorage(){
 try{return await navigator.storage?.persist?.() ?? false}catch{return false}
}
export async function getSetting(key){
 const db=await openDB();return new Promise((resolve,reject)=>{
  const req=db.transaction('settings').objectStore('settings').get(key);
  req.onsuccess=()=>resolve(req.result?.value);req.onerror=()=>reject(req.error);
 });
}
export async function setSetting(key,value){
 const db=await openDB();return new Promise((resolve,reject)=>{
  const tx=db.transaction('settings','readwrite');tx.objectStore('settings').put({key,value});
  tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);
 });
}
