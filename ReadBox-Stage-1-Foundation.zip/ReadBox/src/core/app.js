import {initRouter,navigate,openOverlay,back,current} from './router.js';
import {getSetting,setSetting,requestPersistentStorage} from './db.js';
const $=s=>document.querySelector(s);
const labels={'all-books':'All Books','reading-now':'Reading Now','collections':'Collections','menu':'Menu','settings':'Settings','appearance':'Appearance'};
function render(route,overlay){
 const screen=$('#screen');
 document.querySelectorAll('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.route===route));
 if(overlay){screen.innerHTML=`<section class="page"><button class="back" id="close-panel">← Back</button><h1>${labels[overlay]||overlay}</h1><p class="muted">This screen will be implemented in its scheduled development stage.</p></section>`;$('#close-panel').onclick=()=>back(render);return}
 if(route==='all-books')screen.innerHTML=`<section class="page"><div class="heading-row"><div><p class="eyebrow">YOUR LIBRARY</p><h1>All Books</h1></div><button class="primary" disabled title="Import arrives in Stage 2">＋ Import</button></div><div class="empty"><div class="empty-icon">▤</div><h2>Your library is empty</h2><p>Choose files or a folder to import your books.</p><small>Book importing is coming in Stage 2.</small></div></section>`;
 else if(route==='reading-now')screen.innerHTML=`<section class="page"><p class="eyebrow">PICK UP WHERE YOU LEFT OFF</p><h1>Reading Now</h1><div class="empty compact"><h2>No active books</h2><p>Books you start reading will appear here.</p></div></section>`;
 else if(route==='collections')screen.innerHTML=`<section class="page"><div class="heading-row"><h1>Collections</h1><button class="primary" disabled>＋ New</button></div><div class="empty compact"><h2>No collections yet</h2><p>Organise your library into collections.</p></div></section>`;
 else screen.innerHTML=`<section class="page"><p class="eyebrow">READBOX</p><h1>Menu</h1><div class="menu-list">
 ${['Favorites','To Read','Have Read','Authors','Series','Formats','Folders','Downloads','Trash','Highlights','Notes','Bookmarks','Settings'].map(x=>`<button class="menu-row" data-menu="${x.toLowerCase()}"><span>${x}</span><span>›</span></button>`).join('')}
 </div><footer>ReadBox 2026 All Rights Reserved.</footer></section>`;
 screen.focus();
 document.querySelectorAll('[data-menu]').forEach(b=>b.onclick=()=>navigate(b.dataset.menu,render));
}
document.querySelectorAll('.nav-item').forEach(b=>b.addEventListener('click',()=>navigate(b.dataset.route,render)));
$('#theme-toggle').addEventListener('click',async()=>{
 const currentTheme=document.documentElement.dataset.theme||'system';
 const next=currentTheme==='system'?'dark':currentTheme==='dark'?'light':'system';
 await setSetting('theme',next);applyTheme(next);
});
async function applyTheme(choice){
 document.documentElement.dataset.theme=choice;
 const dark=choice==='dark'||(choice==='system'&&matchMedia('(prefers-color-scheme: dark)').matches);
 document.documentElement.classList.toggle('dark',dark);
 $('#theme-toggle').setAttribute('aria-label',`Theme: ${choice}. Tap to change.`);
}
const saved=await getSetting('theme').catch(()=>null)||'system';await applyTheme(saved);
matchMedia('(prefers-color-scheme: dark)').addEventListener('change',async()=>{if((document.documentElement.dataset.theme||'system')==='system')await applyTheme('system')});
requestPersistentStorage().catch(()=>false);
initRouter(render);
if('serviceWorker'in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register(new URL('../../public/sw.js',import.meta.url)).catch(err=>console.warn('Service worker registration failed',err)));
