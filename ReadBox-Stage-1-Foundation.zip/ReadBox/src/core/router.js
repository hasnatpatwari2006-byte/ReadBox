const ROOTS=new Set(['all-books','reading-now','collections','menu']);
const state={stack:[],overlay:null};
const urlFor=(route)=>`#/${route}`;
export function current(){return state.stack.at(-1)||'all-books'}
export function initRouter(onChange){
 const initial=location.hash.replace(/^#\\//,'')||'all-books';
 state.stack=[initial];history.replaceState({readbox:true,route:initial,stack:[initial]},'',urlFor(initial));
 window.addEventListener('popstate',e=>{
  const s=e.state;
  if(s?.readbox){state.stack=Array.isArray(s.stack)&&s.stack.length?s.stack:[s.route||'all-books'];state.overlay=s.overlay||null}
  else{state.stack=[location.hash.replace(/^#\\//,'')||'all-books'];state.overlay=null}
  onChange(current(),state.overlay);
 });
 onChange(current(),null);
}
export function navigate(route,onChange){
 if(!route||route===current())return;
 if(ROOTS.has(route)){state.stack=[route];state.overlay=null;history.replaceState({readbox:true,route,stack:[route]},'',urlFor(route))}
 else{state.stack.push(route);state.overlay=null;history.pushState({readbox:true,route,stack:[...state.stack]},'',urlFor(route))}
 onChange(route,null);
}
export function openOverlay(id,onChange){
 if(state.overlay===id)return;
 state.overlay=id;history.pushState({readbox:true,route:current(),stack:[...state.stack],overlay:id},'',`${urlFor(current())}?panel=${encodeURIComponent(id)}`);
 onChange(current(),id);
}
export function closeOverlay(onChange){
 if(state.overlay)history.back();
}
export function back(onChange){history.back()}
export function getStack(){return [...state.stack]}
