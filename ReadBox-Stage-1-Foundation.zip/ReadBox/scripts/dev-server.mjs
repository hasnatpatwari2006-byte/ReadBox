import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
const root=join(process.cwd(),'dist'), types={'.html':'text/html','.js':'text/javascript','.css':'text/css','.png':'image/png','.webmanifest':'application/manifest+json'};
http.createServer(async(req,res)=>{try{
 let p=decodeURIComponent((req.url||'/').split('?')[0]); if(p==='/'||p.endsWith('/'))p+='index.html';
 const file=normalize(join(root,p)); if(!file.startsWith(root))throw Error('bad path');
 const data=await readFile(file);res.writeHead(200,{'Content-Type':types[extname(file)]||'application/octet-stream'});res.end(data);
}catch{res.writeHead(404);res.end('Not found');}}).listen(4173,()=>console.log('ReadBox dev server: http://localhost:4173'));
