# ReadBox Android

Native Android starter project for ReadBox, built with Kotlin and Jetpack Compose.

## Current scaffold status

This is the **Phase 1 foundation**, not a finished reader yet:
- Official supplied logo included unchanged.
- All Books, Reading Now, Collections and Menu bottom navigation.
- Settings with System / Dark / Light appearance choice.
- Contact screen with only Facebook and WhatsApp labels.
- Nested navigation/back-stack foundation.
- Android tablet-friendly Compose layout foundation.

Not implemented yet: document import, PDF/EPUB rendering, full-text indexing, OCR, annotations, export, TTS, backup, and production contact URL wiring. Do not publish this scaffold as a finished app.

## Requirements

- Android Studio (current stable)
- JDK 17
- Android SDK Platform 36
- Gradle 8.11.1 (provided automatically by the GitHub Actions workflow)

## Open and run

1. Extract this repository.
2. Android Studio → Open → select the `ReadBox-Android` folder.
3. Allow Gradle sync and install any missing SDK 36 components.
4. Run the `app` configuration on an Android device or emulator.
5. Test system Back, bottom navigation, theme selection, and tablet resizing.

## GitHub workflow

Keep exactly one Android build workflow: `.github/workflows/main.yml`. Do not add a second workflow for the same build, otherwise duplicate runs can occur.

1. Create a **private** GitHub repository named `ReadBox-Android`.
2. Upload/push the contents of this folder to the repository root.
3. Keep `main` protected; do feature work on branches such as `feature/library-import`.
4. Open Pull Requests and review changes before merging.
5. The single workflow at `.github/workflows/main.yml` runs debug unit tests and builds the debug APK on pushes, pull requests, or manual dispatch. It installs Gradle 8.11.1 and Android SDK 36 itself.
6. Download the generated `ReadBox-Android-Debug-APK` artifact from Actions for device testing.

### First push

```bash
git init
git add .
git commit -m "chore: create ReadBox Android foundation"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/ReadBox-Android.git
git push -u origin main
```

## Suggested branch plan

- `feature/library-import`
- `feature/pdf-reader`
- `feature/epub-reader`
- `feature/annotations`
- `feature/search-index`
- `feature/ocr-tts`
- `feature/export-backup`
- `feature/tablet-polish`

## Release safety

- Never commit signing keys, passwords, API tokens, or `local.properties`.
- Use a separate release signing key and store it securely outside the repository.
- Test release builds on real devices before any Play Store submission.
- Play Protect / Play policy approval cannot be guaranteed by source code alone.
