# Add narrowly-scoped keep rules only when a library requires them.
