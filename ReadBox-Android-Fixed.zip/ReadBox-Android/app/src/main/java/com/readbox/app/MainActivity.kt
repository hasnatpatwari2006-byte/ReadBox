package com.readbox.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*

private val MessengerBlue = Color(0xFF0866FF)
private val LightSurface = Color(0xFFF4F6FA)
private val Ink = Color(0xFF17212B)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ReadBoxApp() }
    }
}

@Composable
private fun ReadBoxApp() {
    var themeChoice by rememberSaveable { mutableStateOf("System") }
    val dark = when (themeChoice) {
        "Dark" -> true
        "Light" -> false
        else -> androidx.compose.foundation.isSystemInDarkTheme()
    }
    val colors = if (dark) darkColorScheme(primary = Color(0xFF4D91FF))
                 else lightColorScheme(primary = MessengerBlue, background = LightSurface, surface = Color.White)
    MaterialTheme(colorScheme = colors) {
        val nav = rememberNavController()
        val backStackEntry by nav.currentBackStackEntryAsState()
        val current = backStackEntry?.destination?.route ?: "all"
        val rootTabs = setOf("all", "reading", "collections", "menu")
        BackHandler(enabled = current in rootTabs && current != "all") {
            nav.navigate("all") {
                popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        }
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                if (current in rootTabs) {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        val tabs = listOf(
                            Triple("all", "All Books", Icons.Filled.Home),
                            Triple("reading", "Reading Now", Icons.Filled.MenuBook),
                            Triple("collections", "Collections", Icons.Filled.CollectionsBookmark),
                            Triple("menu", "Menu", Icons.Filled.Menu)
                        )
                        tabs.forEach { (route, label, icon) ->
                            NavigationBarItem(
                                selected = current == route,
                                onClick = {
                                    nav.navigate(route) {
                                        popUpTo(nav.graph.findStartDestination().id) { saveState = true }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                },
                                icon = { Icon(icon, contentDescription = label) },
                                label = { Text(label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { padding ->
            NavHost(navController = nav, startDestination = "all", modifier = Modifier.padding(padding)) {
                composable("all") { AllBooksScreen(onOpenMenu = { nav.navigate("menu") }) }
                composable("reading") { SimpleScreen("Reading Now", "Your recently opened books will appear here.") }
                composable("collections") { SimpleScreen("Collections", "Organize books into your own collections.") }
                composable("menu") { MenuScreen(onSettings = { nav.navigate("settings") }) }
                composable("settings") { SettingsScreen(onContact = { nav.navigate("contact") }, themeChoice = themeChoice, onTheme = { themeChoice = it }) }
                composable("contact") { ContactScreen() }
            }
        }
    }
}

@Composable
private fun AllBooksScreen(onOpenMenu: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.readbox_logo), contentDescription = "ReadBox logo", modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(12.dp))
            Text("ReadBox", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Spacer(Modifier.weight(1f))
            IconButton(onClick = { }) { Icon(Icons.Filled.Search, "Search books") }
            IconButton(onClick = onOpenMenu) { Icon(Icons.Filled.Menu, "Menu") }
        }
        Text("All Books", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text("Your offline library", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(18.dp))
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Filled.MenuBook, null, modifier = Modifier.size(58.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Text("Your library is waiting", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Text("Import PDF, EPUB and other supported books.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(18.dp))
                Button(onClick = { /* File picker is added in the import phase. */ }) {
                    Icon(Icons.Filled.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Import books")
                }
            }
        }
    }
}

@Composable
private fun MenuScreen(onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Menu", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(18.dp))
        MenuRow(Icons.Filled.Settings, "Settings", onSettings)
        MenuRow(Icons.Filled.Info, "About ReadBox") { }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(onContact: () -> Unit, themeChoice: String, onTheme: (String) -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp))
        Text("Appearance", fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("System", "Dark", "Light").forEachIndexed { index, value ->
                SegmentedButton(
                    selected = themeChoice == value,
                    onClick = { onTheme(value) },
                    shape = SegmentedButtonDefaults.itemShape(index, 3)
                ) { Text(value) }
            }
        }
        Spacer(Modifier.height(24.dp))
        MenuRow(Icons.Filled.ContactSupport, "Contact", onContact)
        Spacer(Modifier.weight(1f))
        Text("© 2026 ReadBox. All rights reserved.", modifier = Modifier.fillMaxWidth(), color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
    }
}

@Composable
private fun ContactScreen() {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Contact", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        MenuRow(Icons.Filled.Language, "Facebook") { }
        MenuRow(Icons.Filled.Chat, "WhatsApp") { }
    }
}

@Composable
private fun MenuRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 17.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(16.dp))
        Text(title, fontSize = 17.sp, modifier = Modifier.weight(1f))
        Icon(Icons.Filled.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
}

@Composable
private fun SimpleScreen(title: String, subtitle: String) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
